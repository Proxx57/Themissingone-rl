function afficherFormulaire(){
    document.querySelector("#ajoutForm").removeAttribute("class")
}